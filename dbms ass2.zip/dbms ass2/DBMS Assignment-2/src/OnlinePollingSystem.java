
import java.awt.*;
import java.awt.event.*; 

class OnlinePollingSystem extends Frame implements ActionListener
{ 
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String msg = ""; 
	  Label ll,l2;
	  CardLayout cardLO;
	  insertVoter inv;
	  updateVoter upv;
	  deleteVoter delv;
	  insertAdmin ina;
	  updateAdmin upa;
	  deleteAdmin dela;
	  insertNominee inn;
	  updateNominee upn;
	  deleteNominee deln;
	  insertCity inc;
	  updateCity upc;
	  deleteCity delc;
	  insertParty inp;
	  updateParty upp;
	  deleteParty delp;
	  Panel home,welcome; 
	  
	 OnlinePollingSystem() 
	  { 
			cardLO = new CardLayout(); 
			home = new Panel(); 
			home.setLayout(cardLO);  
			ll = new Label();
			l2 =new Label();
			ll.setAlignment(Label.CENTER);  
			l2.setAlignment(Label.CENTER); 
			ll.setText("Welcome to Online Online Polling System");
			l2.setText("All @rights are reserved");
			welcome = new Panel();
			welcome.add(ll);
			welcome.add(l2);
			inv = new insertVoter(); 
			inv.buildGUI();
			upv = new updateVoter();  
			upv.buildGUI();
			delv = new deleteVoter();	
			delv.buildGUI();
			ina = new insertAdmin();
			ina.buildGUI();
			upa= new updateAdmin();
			upa.buildGUI();
			dela = new deleteAdmin();
			dela.buildGUI();
			inn = new insertNominee();
			inn.buildGUI();
			upn = new updateNominee();
			upn.buildGUI();
			deln = new deleteNominee();
			deln.buildGUI();
			inc = new insertCity();
			inc.buildGUI();
			upc = new updateCity();
			upc.buildGUI();
			delc = new deleteCity();
			delc.buildGUI();
			inp = new insertParty();
			inp.buildGUI();
			upp = new updateParty();
			upp.buildGUI();
			delp =  new deleteParty();
			delp.buildGUI();
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(inv, "insertVoter"); 
			home.add(upv, "updateVoter"); 
			home.add(delv, "deleteVoter"); 
			home.add(ina, "insertAdmin");
			home.add(upa, "updateAdmin");
			home.add(dela, "deleteAdmin");
			home.add(inn, "insertNominee");
			home.add(upn, "updateNominee");
			home.add(deln, "deleteNominee");
			home.add(inc, "insertCity");
			home.add(upc, "updateCity");
			home.add(delc, "deleteCity");
			home.add(inp, "insertParty");
			home.add(upp, "updateParty"); 
			home.add(delp, "deleteParty"); 
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu voter = new Menu("Voter"); 
			MenuItem item1, item2, item3; 
			voter.add(item1 = new MenuItem("Insert Voter")); 
			voter.add(item2 = new MenuItem("View Voter")); 
			voter.add(item3 = new MenuItem("Delete Voter")); 
			mbar.add(voter);  
		 
			Menu nominee = new Menu("Nominee"); 
			MenuItem item4, item5, item6; 
			nominee.add(item4 = new MenuItem("Insert Nominee")); 
			nominee.add(item5 = new MenuItem("View Nominee")); 
			nominee.add(item6 = new MenuItem("Delete Nominee"));  
			mbar.add(nominee); 
			
			Menu admin = new Menu("Admin"); 
			MenuItem item7, item8, item9; 
			admin.add(item7 = new MenuItem("Insert Admin")); 
			admin.add(item8 = new MenuItem("View Admin")); 
			admin.add(item9 = new MenuItem("Delete Admin")); 
			mbar.add(admin);

			Menu party = new Menu("Party"); 
			MenuItem item10, item11, item12; 
			party.add(item10 = new MenuItem("Insert Party")); 
			party.add(item11 = new MenuItem("View Party")); 
			party.add(item12 = new MenuItem("Delete Party")); 
			mbar.add(party);

			Menu city = new Menu("City"); 
			MenuItem item13, item14, item15; 
			city.add(item13 = new MenuItem("Insert City")); 
			city.add(item14 = new MenuItem("View City")); 
			city.add(item15 = new MenuItem("Delete City")); 
			mbar.add(city);			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this); 
			item11.addActionListener(this); 
			item12.addActionListener(this);
			item13.addActionListener(this); 
			item14.addActionListener(this); 
			item15.addActionListener(this);  			
					  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Online Polling System"); 
			Color clr = new Color(50, 150, 100);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.CENTER_BASELINE, 18)); 
			setSize(900, 1000); 
		
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Voter"))
		  {

			cardLO.show(home, "insertVoter"); 			
          }			
		 
		 else if(arg.equals("View Voter")) 
		 {
			 
			cardLO.show(home, "updateVoter"); 			
		 }
		 
		 else if(arg.equals("Delete Voter")) 
		 {
			 
			cardLO.show(home, "deleteVoter"); 			
		 }
		 else if(arg.equals("Insert Nominee"))
		 {
			 
			 cardLO.show(home, "insertNominee"); 
		 }
		 else if(arg.equals("View Nominee"))
		 {
			 
			 cardLO.show(home, "updateNominee");
		 }
		 else if(arg.equals("Delete Nominee"))
		 {
			
			 cardLO.show(home, "deleteNominee");
		 }
		 else if(arg.equals("Insert Admin")) 
		 {
			
			cardLO.show(home, "insertAdmin"); 				
		 }
		 else if(arg.equals("View Admin")) 
		 {
			
			cardLO.show(home, "updateAdmin"); 				
		 }
		 else if(arg.equals("Delete Admin"))
		 {
			 
			 cardLO.show(home, "deleteAdmin");
		 }
		 else if(arg.equals("Insert Party"))
		 {
			
			 cardLO.show(home, "insertParty"); 
		 }
		 else if(arg.equals("View Party"))
		 {
			
			 cardLO.show(home, "updateParty");
		 }
		 else if(arg.equals("Delete Party"))
		 {
			
			 cardLO.show(home, "deleteParty");
		 }
		else if(arg.equals("Insert City"))
		 {
			
			 cardLO.show(home, "insertCity"); 
		 }
		 else if(arg.equals("View City"))
		 {
			 
			 cardLO.show(home, "updateCity");
		 }
		 else
		 {
			 
			 cardLO.show(home, "deleteCity");
		 }			 
	  }
	  public static void main(String ... args)
	  {
			new OnlinePollingSystem();	  
	  }
}
