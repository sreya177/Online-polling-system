

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.*;
import java.sql.*;
public class updateVoter extends Panel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Button updateVoterButton;
	List voterIDList;
	TextField vid,vname, age;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;

	public updateVoter()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch (Exception e)
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}
	public void connectToDB()
	{

		try
		{
			connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sreya","sreya");

			statement = connection.createStatement();

		}
		catch (SQLException connectException)
		{
			System.out.println(connectException.getMessage());
			System.out.println(connectException.getSQLState());
			System.out.println(connectException.getErrorCode());
			System.exit(1);
		}

	}
	
		private void loadProvider()
		{
		try
		{
			rs = statement.executeQuery("SELECT VID FROM voter");
			while (rs.next())
			{
				voterIDList.add(rs.getString("VID"));
			}
		}

		catch (SQLException e)
		{
			displaySQLErrors(e);
		}
	}

	public void buildGUI()
	{
		voterIDList = new List(10);
		loadProvider();
		add(voterIDList);
		voterIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e)
			{
				try
				{
					rs = statement.executeQuery("SELECT * FROM voter");

					while (rs.next())
					{
						if (rs.getString("VID").equals(voterIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast())
					{
						vid.setText(rs.getString("VID"));
						vname.setText(rs.getString("VNAME"));
						age.setText(rs.getString("AGE"));

					}
				}
				catch (SQLException selectException)
				{
					displaySQLErrors(selectException);
				}
			}
		});
		updateVoterButton = new Button("Modify");
		updateVoterButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement(); 
					int i = statement.executeUpdate("UPDATE voter "
					+ "SET vname='" + vname.getText() + "',"
					+ "age=" + age.getText() +" WHERE VID = "
					+ voterIDList.getSelectedItem());

					errorText.append("\nUpdated " + i + " rows ");
					voterIDList.removeAll();
					loadProvider();
				}
				catch (SQLException insertException)
				{
					displaySQLErrors(insertException);
				}
			}
		});
		vid = new TextField(15);
		vid.setEditable(false);
		vname = new TextField(15);
		age = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Voter ID:"));
		first.add(vid);
		first.add(new Label("Voter Name:"));
		first.add(vname);
		first.add(new Label("Voter Age:"));
		first.add(age);
		Panel second = new Panel(new GridLayout(5, 1));
		second.add(updateVoterButton);

		Panel third = new Panel();
		third.add(errorText);

		add(first);
		add(second);
		add(third);

		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);

	}
	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");	
		errorText.append("SQLState: " + e.getSQLState() + "\n");
		errorText.append("VendorError: " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		updateVoter uv = new updateVoter();

		uv.buildGUI();
	}
}