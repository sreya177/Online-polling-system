import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteSailor extends Panel 
{
	Button deleteSailorButton;
	List sailorIDList;
	TextField sidText, snameText, ratingText, ageText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteSailor() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sreya","sreya");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSailors() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM sailors");
		  while (rs.next()) 
		  {
			sailorIDList.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    sailorIDList = new List(10);
		loadSailors();
		add(sailorIDList);
		
		//When a list item is selected populate the text fields
		sailorIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM sailors");
					while (rs.next()) 
					{
						if (rs.getString("SID").equals(sailorIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						sidText.setText(rs.getString("SID"));
						snameText.setText(rs.getString("SNAME"));
						ratingText.setText(rs.getString("RATING"));
						ageText.setText(rs.getString("AGE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteSailorButton = new Button("Delete Sailor");
		deleteSailorButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM sailors WHERE SID = "
							+ sailorIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					sidText.setText(null);
					snameText.setText(null);
					ratingText.setText(null);
					ageText.setText(null);
					sailorIDList.removeAll();
					loadSailors();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		snameText = new TextField(15);
		ratingText = new TextField(15);
		ageText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Sailor ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Rating:"));
		first.add(ratingText);
		first.add(new Label("Age:"));
		first.add(ageText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteSailorButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteSailor dels = new DeleteSailor();
		dels.buildGUI();
	}
}
