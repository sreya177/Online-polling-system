
import java.awt.Button;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.*;
public class insertCity extends Panel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Button insertCityButton;
	TextField cname,cstate;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public insertCity()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(Exception e)
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}
	public void connectToDB()
	{
		try
		{
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sreya","sreya");
			statement=connection.createStatement();
		}
		catch(SQLException connectException)
		{
			System.out.println(connectException.getMessage());
			System.out.println(connectException.getSQLState());
			System.out.println(connectException.getErrorCode());
			System.exit(1);
		}
	}
	public void buildGUI()
	{
		insertCityButton = new Button("Submit");
		insertCityButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement();
					String query="INSERT INTO city VALUES('" + cname.getText() + "', " + "'" + cstate.getText()+ "')";
					int i=statement.executeUpdate(query);
					errorText.append("\nInserted"+i+"rows.");
				}
				catch(SQLException insertException)
				{
					displaySQLErrors(insertException);
				}
			}
		}
				);
		cname=new TextField(20);
		cstate=new TextField(20);
		
		errorText=new TextArea(10,40);
		errorText.setEditable(false);
		Panel first=new Panel();
		first.setLayout(new GridLayout(5,2));
		first.add(new Label("CITY NAME:"));
		first.add(cname);
		first.add(new Label("CITY STATE:"));
		first.add(cstate);
		first.setBounds(200,150,400,150);
		Panel second=new Panel(new GridLayout(4,1));
		second.add(insertCityButton);
		second.setBounds(200,300,350,150);
		Panel third=new Panel();
		third.add(errorText);
		third.setBounds(200,450,700,600);
		setLayout(null);
		add(first);
		add(second);
		add(third);
		setSize(500,600);
		setVisible(true);
		
	}
	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException:"+e.getMessage()+"\n");
		errorText.append("SQLState: "+e.getSQLState()+"\n");
		errorText.append("VoterError: "+e.getErrorCode()+"\n");
	}
	public static void main(String[] args)
	{
		insertCity city=new insertCity();
		city.buildGUI();
	}
}
