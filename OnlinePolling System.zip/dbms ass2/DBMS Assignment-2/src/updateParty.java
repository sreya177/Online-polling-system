





import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.*;
import java.sql.*;
public class updateParty extends Panel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Button updatePartyButton;
	List partyNameList;
	TextField pname,state,founder,estb;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;

	public updateParty()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch (Exception e)
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}
	public void connectToDB()
	{

		try
		{
			connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sreya","sreya");

			statement = connection.createStatement();

		}
		catch (SQLException connectException)
		{
			System.out.println(connectException.getMessage());
			System.out.println(connectException.getSQLState());
			System.out.println(connectException.getErrorCode());
			System.exit(1);
		}

	}
	
		private void loadProvider()
		{
		try
		{
			rs = statement.executeQuery("SELECT PNAME FROM party");
			while (rs.next())
			{
				partyNameList.add(rs.getString("PNAME"));
			}
		}

		catch (SQLException e)
		{
			displaySQLErrors(e);
		}
	}

	public void buildGUI()
	{
		partyNameList = new List(10);
		loadProvider();
		add(partyNameList);
		partyNameList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e)
			{
				try
				{
					rs = statement.executeQuery("SELECT * FROM party");

					while (rs.next())
					{
						if (rs.getString("PNAME").equals(partyNameList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast())
					{
						pname.setText(rs.getString("PNAME"));
						state.setText(rs.getString("STATE"));
						founder.setText(rs.getString("FOUNDER"));
						estb.setText(rs.getString("ESTABLISHED"));

					}
				}
				catch (SQLException selectException)
				{
					displaySQLErrors(selectException);
				}
			}
		});
		updatePartyButton = new Button("Modify");
		updatePartyButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement(); 
					int i = statement.executeUpdate("UPDATE party "
							+ "SET state='" + state.getText() + "', "
							+ "founder='"+ founder.getText() +"', "
							+ "established ="+ estb.getText() + " WHERE pname = '"
							+ partyNameList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows ");
					partyNameList.removeAll();
					loadProvider();
				}
				catch (SQLException insertException)
				{
					displaySQLErrors(insertException);
				}
			}
		});
		pname = new TextField(15);
		pname.setEditable(false);
		state = new TextField(15);
		founder = new TextField(15);
		estb = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Party Name:"));
		first.add(pname);
		first.add(new Label("State:"));
		first.add(state);
		first.add(new Label("Founder:"));
		first.add(founder);
		first.add(new Label("Established:"));
		first.add(estb);
		Panel second = new Panel(new GridLayout(5, 1));
		second.add(updatePartyButton);

		Panel third = new Panel();
		third.add(errorText);

		add(first);
		add(second);
		add(third);

		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);

	}
	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");	
		errorText.append("SQLState: " + e.getSQLState() + "\n");
		errorText.append("VendorError: " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		updateParty up = new updateParty();

		up.buildGUI();
	}
}
